This is a server folder for customer images, each deployment need to back up this folder and restore it back after new deployment
